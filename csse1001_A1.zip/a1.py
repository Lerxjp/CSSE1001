"""
CSSE1001 2019s2a1
"""

from a1_support import *


# Write the expected functions here


def main():
    pass


if __name__ == "__main__":
    main()
